@extends('layouts.intranet')

@section('content')
    <iniciar-sesion></iniciar-sesion>
@endsection
