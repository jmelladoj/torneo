@extends('layouts.intranet')

@section('content')
    <home></home>
@endsection
